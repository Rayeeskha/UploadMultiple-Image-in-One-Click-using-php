<?php

//database_connection.php Khan Rayees Software Developer

$connect = new PDO('mysql:host=localhost;dbname=touchshopping', 'root', '');
// if ($connect) {
// 	# code...
// 	echo "connect";
// }else{
// 	echo "Not connected";
// }

?>