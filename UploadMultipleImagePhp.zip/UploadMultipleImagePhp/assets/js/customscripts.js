$(document).ready(function(){
$(".add_details").click(function(){
        $(".user-details").append(' <div class="user_data"><div class="form-group"><label class="control-label">Price</label><input name="price" class="form-control"  autocomplete="false" type="number"></div><span class="remove-btn btn btn-danger" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span></div>');
        });

$("body").on("click",".remove-btn",function(e){
       $(this).parents('.user_data').remove();
  });

});

function dynInput(cbox) {
  	if (cbox.checked) {
  		$('#inputs').show();
  	} 
  	else {
    	$('#inputs').hide();
  	}
}
